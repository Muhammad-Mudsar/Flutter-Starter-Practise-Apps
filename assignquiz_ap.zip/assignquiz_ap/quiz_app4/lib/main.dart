import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'contactC.dart';
import 'mdlresult.dart';
import 'final.dart';
import 'MySplash.dart';
import 'quiZBrain.dart';
import 'package:percent_indicator/percent_indicator.dart';

QuizBrain quizBrain;
void main() => runApp(MaterialApp(
  home: Splash(),
));

class QuizApp extends StatefulWidget {
  //const QuizApp({ Key? key }) : super(key: key);
  QuizApp() {
    quizBrain = QuizBrain();
  }

  @override
  _QuizAppState createState() => _QuizAppState();
}

class _QuizAppState extends State<QuizApp> {
  List<Icon> scoreKeeper = [];
  List<MdlResult> record = [];
  int Qattempted = 0;
  getnextQuestion() {
    setState(() {
      if (quizBrain.isFinished()) {
        time.cancel();
        tsec = 5;
        _dispDialog();
        quizBrain.reset();
        scoreKeeper = [];
      } else {
        quizBrain.nextQuestion();
        setState(() {});
      }
    });
  }

  _dispDialog() {
    Navigator.pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => Result(record, Qattempted),
      ),
    );
  }

  void checkAnswer(bool userPickedAnswer) {
    bool correctAnswer = quizBrain.getCorrectAnswer();
    Qattempted++;

    setState(() {
      if (quizBrain.isFinished() == true) {
        time.cancel();
        tsec = 5;
        _dispDialog();

        quizBrain.reset();
        scoreKeeper = [];
      } else {
        if (userPickedAnswer == correctAnswer) {
          tsec = 5;
          scoreKeeper.add(Icon(
            Icons.check,
            color: Colors.green,
          ));
        } else {
          record.add(
              MdlResult(quizBrain.question, userPickedAnswer, correctAnswer));
          tsec = 5;
          scoreKeeper.add(
            Icon(
              Icons.close,
              color: Colors.red,
            ),
          );
        }
        quizBrain.nextQuestion();
      }
    });
  }

  int tsec = 5;
  Timer time;
  bool first = true;
  _startTimer() {
    time = Timer.periodic(
      Duration(seconds: 1),
          (Timer t) {
        setState(() {
          if (this.tsec > 0) {
            this.tsec = this.tsec - 1;
          } else {
            this.tsec = 5;
            getnextQuestion();
            setState(() {});
          }
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (first) {
      first = false;
      _startTimer();
    }
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        drawerEnableOpenDragGesture: true,
        appBar: AppBar(
          title: Text("           REG:  FA19_BCS_047"),
          bottomOpacity: 0,
          backgroundColor: Colors.lightGreen,
          toolbarOpacity: 0.9,
        ),
        drawer: Drawer(
          child: ListView(
            children: [

              UserAccountsDrawerHeader(
                currentAccountPicture: Image(image: AssetImage("img/user.png")),
                accountName: Text("Muhammad Mudsar"),
                accountEmail: Text("muhammadmudsarch@gmail.com"),
              ),

              ListTile(
                subtitle: Text(
                  "Total Questions: 10",
                  style: TextStyle(fontSize: 20),
                ),
              ),
              ListTile(
                subtitle: Text(
                  "Remaining Questions: ${10 - Qattempted}",
                  style: TextStyle(fontSize: 20),
                ),
              ),
              ListTile(
                subtitle: Text(
                  "Total Correct Answers:${Qattempted - record.length}",
                  style: TextStyle(fontSize: 20),
                ),
              ),
              ListTile(
                subtitle: Text(
                  "Total Wrong Answers: ${record.length}",
                  style: TextStyle(fontSize: 20),
                ),
              ),
              Divider(
                thickness: 3,
                indent: 40,
                endIndent: 40,
                color: Colors.blueGrey.shade600,
              ),
              SizedBox(
                height: 50,
              ),
              ListTile(
                leading: Icon(Icons.contact_mail_sharp),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (BuildContext context) => Contact(),
                      ));
                },
                title: Text(
                  "Contact Us",
                  style: TextStyle(fontSize: 20),
                ),


              ),
              SizedBox(
                height: 40,
              ),
              ListTile(
                leading: Icon(Icons.design_services),
                title: Text('Our services'),

              ),
              ListTile(
                leading: Icon(Icons.add_ic_call_outlined),
                title: Text('About Us'),


              ),

            ],
          ),
        ),
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(50),
                  child: CircularPercentIndicator(
                    // animation: true,
                    radius: 100.0,
                    lineWidth: 7.0,
                    percent: (tsec / 10) * 2,
                    linearGradient: LinearGradient(
                        colors: [Colors.blue.shade900, Colors.red]),

                    center: new Text(
                      tsec.toString(),
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    //progressColor: Colors.green,
                  ),
                ),
                Expanded(
                  flex: 4,
                  child: Padding(
                    padding: EdgeInsets.all(10.0),
                    child: Center(
                      child: Text(
                        quizBrain.getQuestionText(),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 25.0,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    height: 50,
                    padding: EdgeInsets.all(15.0),
                    child: FlatButton(
                      textColor: Colors.white,
                      color: Colors.green,
                      child: Text(
                        'True',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20.0,
                        ),
                      ),
                      onPressed: () {
                        checkAnswer(true);
                        //The user picked true.
                      },
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(15.0),
                    child: FlatButton(
                      color: Colors.red,
                      child: Text(
                        'False',
                        style: TextStyle(
                          fontSize: 20.0,
                          color: Colors.white,
                        ),
                      ),
                      onPressed: () {
                        checkAnswer(false);
                        //The user picked false.
                      },
                    ),
                  ),
                ),
                Row(
                  children: scoreKeeper,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
