class MdlResult {
  int qNo = 0;
  bool correct;
  bool user;
  MdlResult(this.qNo, this.user, this.correct);
}
